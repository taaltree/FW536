# FW 536: install every R package the course uses.
# Run once, with FW536.Rproj open:   source("00_install_packages.R")
#
# Nimble also needs a C++ compiler (Rtools on Windows, Xcode Command Line Tools
# on Mac). See https://taaltree.github.io/FW536/install_jags_nimble.html
#
# This file is generated from the course code by _tools/build_student_project.py.

pkgs <- c(
  "AICcmodavg", "boot", "coda", "dplyr", "effects", "emmeans",
  "GGally", "ggplot2", "HDInterval", "here", "knitr", "lattice",
  "lme4", "MASS", "MCMCvis", "MuMIn", "nimble", "nlme",
  "plotly", "rmarkdown", "tidyr"
)

missing <- setdiff(pkgs, rownames(installed.packages()))
if (length(missing) == 0) {
  message("All ", length(pkgs), " course packages are already installed.")
} else {
  message("Installing ", length(missing), " package(s): ", paste(missing, collapse = ", "))
  install.packages(missing)
}

still_missing <- setdiff(pkgs, rownames(installed.packages()))
if (length(still_missing) > 0) {
  warning("These packages did not install: ", paste(still_missing, collapse = ", "),
          ". See the setup guide's troubleshooting section.")
} else {
  message("Done. Every course package is installed.")
}
