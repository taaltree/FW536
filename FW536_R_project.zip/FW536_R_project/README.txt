FW 536 · Statistical Modeling for Ecology and Conservation
Course R project
============================================================

1. Unzip this folder anywhere on your computer (not inside another zip viewer).
2. Double-click FW536.Rproj. RStudio opens with this folder as the project.
3. Run this once in the RStudio Console to install the course packages:

       source("00_install_packages.R")

   Nimble also needs a C++ compiler. See the setup guide:
   https://taaltree.github.io/FW536/install_jags_nimble.html

Each day has its own folder:

   DayN_.../data/                  the datasets for that day
   DayN_.../*_lab_template.Rmd     the R Markdown hand-in templates
   DayN_.../*.R                    the R scripts used in the labs

All course code finds data with here::here(), for example

   read.csv(here::here("Day4_Likelihood_BayesI", "data", "vonbert.csv"))

That works from the Console, from a script, and when you knit a template, as
long as you opened FW536.Rproj first. Do not rename the day folders or move
the data files.

Course website: https://taaltree.github.io/FW536/
